
import turtle
sam = turtle.Turtle()
sam.hideturtle()
sam.dot()
for x in range(7):
    if(x%2 == 0):
        sam.pendown()
    else:
        sam.penup()
    sam.forward(20)
sam.dot()
sam.left(90)
sam.forward(140)
sam.dot()
sam.left(90)
for x in range(7):
    if(x%2 == 0):
        sam.pendown()
    else:
        sam.penup()
    sam.forward(20)
sam.dot()
sam.left(90)
sam.forward(140)
sam.dot()
sam.left(135)
sam.forward(197.98)
sam.right(135)
sam.forward(140)
sam.right(135)
sam.forward(197.98)
sam.back(98.99)
sam.dot()


