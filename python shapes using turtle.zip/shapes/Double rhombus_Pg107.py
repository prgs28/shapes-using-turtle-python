
import turtle
sam = turtle.Turtle()
sam.hideturtle()
sam.setheading(135)
for x in range(4):
    sam.forward(100)
    sam.right(90)
sam.right(90)
sam.forward(100)
for x in range(4):
    sam.forward(100)
    sam.right(90)
turtle.done()

