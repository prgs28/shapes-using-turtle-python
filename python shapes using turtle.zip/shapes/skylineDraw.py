
import turtle
turtle.setup(640,480)
turtle.penup()
turtle.goto(0,100)
turtle.bgcolor('black')
turtle.pendown()

#firstBuilding

turtle.color('white')
turtle.pencolor('grey')
turtle.fillcolor('grey')
turtle.begin_fill()
for i in range(4):
    if(i%2 == 0):
        turtle.forward(150)
    else:
        turtle.forward(375)
    turtle.right(90)
turtle.end_fill()
turtle.penup()

#secondBuilding
turtle.goto(100,50)
turtle.pendown()
turtle.fillcolor('grey')
turtle.begin_fill()
for i in range(4):
    if(i%2 == 0):
        turtle.forward(70)
    else:
        turtle.forward(305)
    turtle.right(90)
turtle.end_fill()
turtle.penup()
turtle.goto(150,200)
turtle.pendown()
turtle.hideturtle()

#thirdBuilding
turtle.fillcolor('grey')
turtle.begin_fill()
for i in range(4):
    if(i%2 == 0):
        turtle.forward(80)
    else:
        turtle.forward(450)
    turtle.right(90)
turtle.end_fill()
turtle.goto(225,75)
turtle.fillcolor('grey')
turtle.begin_fill()
for i in range(4):
    if(i%2 == 0):
        turtle.forward(100)
    else:
        turtle.forward(315)
    turtle.right(90)
turtle.end_fill()
turtle.penup()
turtle.goto(0,60)
turtle.setheading(180)
turtle.pendown()

#nextBuilding
turtle.fillcolor('grey')
turtle.begin_fill()
for i in range(4):
    if(i%2 == 0):
        turtle.forward(150)
    else:
        turtle.forward(295)
    turtle.left(90)
turtle.end_fill()
turtle.penup()
turtle.goto(-150,150)
turtle.pendown()
turtle.fillcolor('grey')
turtle.begin_fill()
for i in range(4):
    if(i%2 == 0):
        turtle.forward(80)
    else:
        turtle.forward(385)
    turtle.left(90)
turtle.end_fill()
turtle.penup()
turtle.goto(-230,40)
turtle.pendown()

turtle.fillcolor('grey')
turtle.begin_fill()
for i in range(4):
    if(i%2 == 0):
        turtle.forward(90)
    else:
        turtle.forward(275)
    turtle.left(90)
turtle.end_fill()
turtle.penup()
turtle.goto(20,50)
turtle.right(90)
turtle.right(90)

#windows
turtle.pendown()
turtle.fillcolor('yellow')
turtle.begin_fill()
for i in range(4):
    turtle.forward(20)
    turtle.left(90)
turtle.end_fill()
turtle.penup()
turtle.goto(20,10)
turtle.pendown()
turtle.fillcolor('yellow')
turtle.begin_fill()
for i in range(4):
    turtle.forward(20)
    turtle.left(90)
turtle.end_fill()
turtle.penup()
turtle.goto(165,175)
turtle.pendown()
turtle.fillcolor('yellow')
turtle.begin_fill()
for i in range(4):
    turtle.forward(20)
    turtle.left(90)
turtle.end_fill()
turtle.penup()
turtle.goto(-200,100)
turtle.pendown()
turtle.fillcolor('yellow')
turtle.begin_fill()
for i in range(4):
    turtle.forward(20)
    turtle.left(90)
turtle.end_fill()
turtle.penup()
turtle.goto(-260,10)
turtle.pendown()
turtle.fillcolor('yellow')
turtle.begin_fill()

for i in range(4):
    turtle.forward(20)
    turtle.left(90)
turtle.end_fill()
turtle.penup()
turtle.goto(125,200)

#stars
turtle.pencolor('white')
turtle.dot()
turtle.goto(400,200)
turtle.dot()
turtle.goto(-200,200)
turtle.dot()
turtle.goto(100,200)
turtle.dot()
turtle.goto(-50,200)
turtle.dot()
turtle.goto(-25,200)
turtle.dot()
turtle.goto(-300,175)
turtle.dot()


