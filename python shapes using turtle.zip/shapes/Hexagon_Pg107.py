
import turtle
sam = turtle.Turtle()
sam.hideturtle()
for x in range(4):
    sam.forward(100)
    sam.left(90)
sam.left(90)
sam.penup()
sam.forward(100)
sam.pendown()
for x in range(4):
    sam.forward(100)
    sam.left(90)
sam.left(45)
sam.forward(141.42)
sam.back(282.84)
sam.right(45)
sam.forward(100)
sam.left(45)
sam.forward(141.42)
sam.left(45)
sam.forward(100)
sam.left(90)
sam.forward(100)
sam.left(45)
sam.forward(141.42)
turtle.done()



