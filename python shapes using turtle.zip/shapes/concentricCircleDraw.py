
#concentric squares

import turtle
turtle.setheading(180)
side = 20
turtle.goto(0,0)
for i in range(50):
    for j in range(4):
        turtle.forward(side)
        turtle.right(90)
    side = side + 3 #side increased by 3 
turtle.done()


        
    
