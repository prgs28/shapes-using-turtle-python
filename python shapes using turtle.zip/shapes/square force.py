#pragyaTrivedi-1001518488

import turtle
sam = turtle.Turtle()
sam.penup()
sam.goto(100,100)
sam.pendown()
for i in range(4):
    sam.forward(20)
    sam.left(90)
sam.penup()
sam.goto(0,0)
length = int(input("Enter the force between 120 and 150"))
angle = int(input("Enter the projectile angle 30 and 60"))
sam.pendown()
sam.setheading(angle)
sam.forward(length)
if((length >= 141 and length <= 145 ) and angle == 45):
    print("Hit")
else:
    print("Miss")
if(length <= 141):
    print("More Force")
elif(length>=145):
    print("Less Force")
else:
    print("Appropriate force")
if(angle < 45):
    print("More Angle")
elif(angle > 45):
    print("Less Angle")
else:
    print("Appropriate angle")
print("Good Attempt")
