
import turtle
sam = turtle.Turtle()
sam.hideturtle()
for x in range(5):
    if(x%2==0):
        sam.pendown()
        sam.circle(50)
    else:
        sam.penup()
        sam.forward(125)
sam.setheading(135)
sam.penup()
sam.forward(70)
sam.left(45)
sam.forward(10)
sam.pendown()
sam.circle(50)
sam.penup()
sam.forward(125)
sam.pendown()
sam.circle(50)

        
    
