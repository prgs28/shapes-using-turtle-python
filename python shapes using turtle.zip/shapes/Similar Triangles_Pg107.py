
import turtle
sam = turtle.Turtle()
sam.hideturtle()
sam.left(60)
for x in range(3):
    sam.forward(100)
    sam.right(120)
sam.right(30)
sam.forward(58)
sam.right(60)
sam.forward(58)
turtle.done()
